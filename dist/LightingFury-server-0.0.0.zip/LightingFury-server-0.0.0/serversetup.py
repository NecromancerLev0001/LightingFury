'''
Created on 2014. 3. 21.

@author: Su-Jin Lee
'''

from distutils.core import setup

setup(name = "LightingFury-server",
      version = "0.0.0",
      author = "Su-Jin Lee",
      author_email = "kanobaoha@gmail.com",
      url = "#",
      license = "MIT",
      packages = ["LF"],
      scripts = ["lfserver.py", ], )