LightingFury
============

>This is unlimited P2P chatting program.
>>* You can chat with all if you can..
>>* This program can send message to all if all connected..


>program description
>>* lfserver: server side program
>>* lfpeer: peer program
>>* winpeer: windows peer program
>>* How it works: http://www.youtube.com/watch?v=NOSc0sHOz9I


>etc..
>>* Language support: English only 
>>* It’s just test version so this program may be some errors.
>>* I want to know people want this program and program run complete..


>Written by Su-Jin Lee(kanobaoha@gmail.com)
